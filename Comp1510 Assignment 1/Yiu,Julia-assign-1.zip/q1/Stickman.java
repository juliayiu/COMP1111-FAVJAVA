package q1;


/**
 * <p>A</p>
 *
 * @author Julia Yiu
 * @version 1.0
 */
public class Stickman {
    /**
     * <p>This is the main method (entry point) that gets called by the JVM.</p>
     *
     * @param args command line arguments.
     */
    public static void main(String[] args) {
        System.out.println();
        System.out.println("   /\"\"\"\"\"\"\"\\");
        System.out.println("  |  (o|o)  |");
        System.out.println("  |  '---'  |");
        System.out.println("   \\_______/");
        System.out.println("   ___| |___");
        System.out.println("  /   '-'   \\");
        System.out.println(" |  .     .  |");
        System.out.println("  \\_|_____|_/");
        System.out.println("  /_|     |_\\");
        System.out.println("   |  .-.  |");
        System.out.println("   '._| |_.'");
        System.out.println("   /__| |__\\");
        
        System.out.println("Question one was called and ran sucessfully.");
    }

};
