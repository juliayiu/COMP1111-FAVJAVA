package q5;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 * <p>A graphics application that draws a business card including:
 * name, company name, address, phone number, fax number, email address, 
 * and web site. 
 * </p>
 *
 * @author Julia Yiu
 * @version 1.0
 */
public class BusinessCard extends JFrame {
    /**
     * This is the generated serial ID for BusinessCard.
     */
    private static final long serialVersionUID = 7062469334560391173L;

    /**
     * This is the x-coordinate size for the Business Card.
     */
    private static final int X_BOX = 400;
    /**
     * This is the y-coordinate size for the Business Card.
     */
    private static final int Y_BOX = 240;
    
    /**
     * <p>The default constructor which sets the title of this app, sets the
     * default close operation to exit, creates a new content pane and finally
     * sets size and sets the visibility of this frame to true (show).</p>
     */
    public BusinessCard() {
        super("Julia Yiu");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setContentPane(new BusinessCardPanel());
        setSize(X_BOX, Y_BOX);
        setVisible(true);
    }

    /**
     * <p>A panel that acts as the Frame's content pane.</p>
     */
    class BusinessCardPanel extends JPanel {

        /**
         * Generated serial ID.
         */
        private static final long serialVersionUID = 7707485562200870103L;
        /**
         * <p>An image object that can be used to paint to the panel.</p>
         */
        private Image img;

        /**
         * <p>The default constructor that retrieves an image to draw.</p>
         */
        public BusinessCardPanel() {
            // NOTE: IF YOU ADD AN IMAGE YOU NEED TO LEAVE 'q5' IN THE STRING!
            img = new ImageIcon(BusinessCardPanel.class.getResource(
                "/q5/coffee.jpg")).getImage();
        }

        /**
         * <p>Called by the environment when the frame needs to be updated.</p>
         *
         * @param g the graphics context with which we paint into.
         */
        public void paintComponent(Graphics g) {
            super.paintComponent(g);
          
            final int xRECT = 0;
            final int yRECT = 0;
            final int wRECT = 400;
            final int hRECT = 250;

            final int xPOSITION = 20;
            final int yPOSITION = 30;
            
            final int xNAME = 20;
            final int yNAME = 50;
            
            final int xNAME1 = 20;
            final int yNAME1 = 70;
            
            final int xCONTACT = 20;
            final int yCONTACT = 155;
            
            final int xPHONE = 20;
            final int yPHONE = 175;    
            
            final int xFAX = 20;
            final int yFAX = 195;   
            
            final int xEMAIL = 20;
            final int yEMAIL = 215;
            
            final int xSITE = 20;
            final int ySITE = 235;
            
            final int xIMG = 180;
            final int yIMG = 70;
            final int wIMG = 220;
            final int hIMG = 170;
            
            final int fontsize = 20;
            
            g.drawRect(xRECT, yRECT, wRECT, hRECT);
            setBackground(Color.white);
            g.setColor(Color.black);
            g.drawImage(img, xIMG, yIMG, wIMG, hIMG, this);
            g.drawString("Julia Yiu", xNAME, yNAME);
            g.drawString("Co-Founder/Head Manager", xNAME1, yNAME1);
            g.drawString("1234 Coffee Ave.", xCONTACT, yCONTACT);
            g.drawString("Office #: (604)123-4567 ", xPHONE, yPHONE);
            g.drawString("Fax #: (604)123-4566 ", xFAX, yFAX);
            g.drawString("Email: julia.coffeecompany@gmail.com ", 
                    xEMAIL, yEMAIL);
            g.drawString("Website: www.juliascoffeecompany.com", 
                    xSITE, ySITE);
            g.setFont(new Font("default", Font.BOLD, fontsize));
            g.drawString("Julia's Coffee Factory", xPOSITION, yPOSITION);
        }
    }

    /**
     * <p>The main method.</p>
     * @param args command line arguments
     */
    public static void main(String[] args) {
        new BusinessCard();
    }

}
