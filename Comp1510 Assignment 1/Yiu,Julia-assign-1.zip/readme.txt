[Julia Yiu], [A00902410], [1A], [FEB 8, 2014]

This assignment is [enter percent]% complete.


------------------------
Question one (Stickman) status:

[complete or not complete]
[explanation if not complete, what is working/not working]

------------------------
Question two (SecondsConvert) status:

[complete or not complete]
[explanation if not complete, what is working/not working]

------------------------
Question three (TempConvert) status:

[complete or not complete]
[explanation if not complete, what is working/not working]

------------------------
Question four (Cylinder) status:

[complete or not complete]
[explanation if not complete, what is working/not working]

------------------------
Question five (BusinessCard) status:

[complete or not complete]
[explanation if not complete, what is working/not working]
